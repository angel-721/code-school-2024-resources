// Did you restart your server?
// Make your server with express

// define a student's collection
// it might be a good idea to have a single student in it
// student = {name: "student_name", major: "student_major"}
//
//
//
//

// make a GET endpoint for students that returns the json of your students
// collection
// If you get a COR's error you might want to see if you are setting the
// Access-Control-Allow-Origin header to the right value
//
//
//

// Make a POST endpoint for students
// add the new student to your collection
// You might find it helpful to set the CORS header
// You might want to see how the request.body looks and check to see if you are
// using a setting used in the express example

// start your server on whatever port you want

